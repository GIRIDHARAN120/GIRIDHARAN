---
id: translations
guide: yarn_organization
layout: guide
---

Documentation is written in English through the repository on GitHub.
Translations are managed through [Crowdin](https://crowdin.com/).

If would like to contribute to translations you can
[join our team here](http://i18n.yarnpkg.com/project/yarn/invite).

Once you sign up for an account you can click on your language and start
writing translations.

Remember that the [code of conduct]({{url_base}}/org/code-of-conduct) also
applies to anything that happens on Crowdin.
