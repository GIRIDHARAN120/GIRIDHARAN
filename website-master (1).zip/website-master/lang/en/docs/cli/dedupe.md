---
id: docs_cli_dedupe
guide: docs_cli
layout: guide
---

{% include vars.html %}

The dedupe command isn't necessary. `yarn install` will already dedupe.
