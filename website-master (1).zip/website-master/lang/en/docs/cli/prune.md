---
id: docs_cli_prune
guide: docs_cli
layout: guide
---

{% include vars.html %}

The prune command isn't necessary. `yarn install` will prune extraneous packages.
