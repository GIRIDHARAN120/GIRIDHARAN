You will need to set up the `PATH` environment variable in your terminal to have access to Yarn's binaries globally.

Add `set PATH=%PATH%;C:\.yarn\bin` to your shell environment.
