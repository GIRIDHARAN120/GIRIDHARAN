## Install via npm

It is recommended to install Yarn through the [npm package manager](http://npmjs.org/), which comes bundled with [Node.js](https://nodejs.org/) when you install it on your system.

Once you have npm installed you can run the following both to **install** and **upgrade** Yarn:

```sh
npm install --global yarn
```
